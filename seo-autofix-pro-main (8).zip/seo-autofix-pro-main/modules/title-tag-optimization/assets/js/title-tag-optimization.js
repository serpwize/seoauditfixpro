/**
 * Title Tag Optimization — Admin JavaScript
 * Fully isolated. No imports from Image SEO or Broken URL modules.
 *
 * @package SEO_AutoFix_Pro
 */
/* global titleTagData, jQuery */
(function ($) {
    'use strict';

    /* =========================================================
     * Constants
     * ========================================================= */
    var PAGE_SIZE = 25;

    /* =========================================================
     * Module State
     * ========================================================= */
    var TitleTag = {
        allRows: [],            // All rows from current scan
        typeFilteredRows: [],   // After post type filter
        visibleRows: [],        // After issue filter applied
        activeFilter: '',       // '' = no filter (show all)
        postTypeFilter: 'all',  // 'all', 'post', or 'page'
        currentPage: 1,
        cancelGeneration: false,
        appliedChanges: [],     // For CSV export — resets on filter change
        skippedIds: [],
        lockedUrls: [],         // URLs locked from bulk actions
        scanSnapshot: []        // Deep copy of allRows at scan completion (for undo)
    };

    /* =========================================================
     * DOM Ready
     * ========================================================= */
    $(document).ready(function () {
        bindEvents();
    });

    function bindEvents() {
        $('#titletag-scan-btn').on('click', startScan);
        $('#titletag-reset-filter-btn').on('click', resetFilter);
        $('#titletag-bulk-generate-btn').on('click', bulkGenerate);
        $('#titletag-bulk-apply-btn').on('click', bulkApply);
        $('#titletag-cancel-btn').on('click', function () { TitleTag.cancelGeneration = true; });
        $('#titletag-export-csv-btn').on('click', exportCSV);
        $('#titletag-scan-export-btn').on('click', exportScanCSV);
        $('#titletag-undo-btn').on('click', undoChanges);

        // Post type dropdown
        $('#titletag-posttype-filter').on('change', function () {
            applyPostTypeFilter($(this).val());
        });

        // Lock modal
        $('#titletag-lock-btn').on('click', openLockModal);
        $('.titletag-lock-modal-close, .titletag-lock-modal-overlay').on('click', closeLockModal);
        $('#titletag-lock-done-btn').on('click', processLockUrls);
        $('#titletag-lock-clear-btn').on('click', function () {
            $('#titletag-lock-urls-input').val('');
        });

        // Filter radio cards — ignore clicks on the <input> itself to prevent double-fire
        $(document).on('click', '.titletag-filter-card', function (e) {
            if ($(e.target).is('input')) { return; }
            var val = $(this).data('filter');
            setFilter(val);
            $(this).find('input[type="radio"]').prop('checked', true);
        });

        // Row-level events (delegated)
        $('#titletag-tbody')
            .on('click', '.titletag-generate-btn', function () {
                generateSingle($(this).closest('tr'), false);
            })
            .on('click', '.titletag-apply-btn', function () {
                applySingle($(this).closest('tr'));
            })
            .on('click', '.titletag-skip-btn', function () {
                skipRow($(this).closest('tr'));
            })
            .on('input', '.titletag-suggested-editable', function () {
                var $row = $(this).closest('tr');
                updateCharCounter($(this));
                $row.find('.titletag-apply-btn').prop('disabled', $(this).text().trim().length === 0);
            });
    }

    /* =========================================================
     * Scan
     * ========================================================= */
    function startScan() {
        $('#titletag-scan-btn').prop('disabled', true).text('Scanning\u2026');
        $('#titletag-empty-state').hide();
        $('#titletag-results').hide();
        $('#titletag-stats').hide();
        $('#titletag-controls').hide();
        $('#titletag-scan-progress').show();
        setProgress(0);

        TitleTag.allRows = [];
        TitleTag.appliedChanges = [];
        TitleTag.skippedIds = [];
        TitleTag.activeFilter = '';
        TitleTag.currentPage = 1;

        fetchScanBatch(0);
    }

    function fetchScanBatch(offset) {
        $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_scan',
                nonce: titleTagData.nonce,
                offset: offset,
                post_type: 'any',
                issue_filter: 'all'
            },
            success: function (res) {
                if (!res.success) {
                    showToast('Scan error: ' + res.data.message, 'error');
                    scanComplete(); return;
                }
                var data = res.data;
                TitleTag.allRows = TitleTag.allRows.concat(data.results || []);
                if (data.stats && offset === 0) { renderStats(data.stats); }
                setProgress(data.hasMore ? 50 : 100);
                if (data.hasMore) { fetchScanBatch(data.offset); }
                else { scanComplete(); }
            },
            error: function () {
                showToast('Scan failed. Check the debug log.', 'error');
                scanComplete();
            }
        });
    }

    function scanComplete() {
        $('#titletag-scan-progress').hide();
        $('#titletag-scan-btn')
            .prop('disabled', false)
            .html('<span class="dashicons dashicons-search"></span> Scan Posts &amp; Pages');

        if (TitleTag.allRows.length === 0) {
            $('#titletag-scan-export-btn').hide();
            $('#titletag-empty-state').show(); return;
        }

        $('#titletag-stats').show();
        $('#titletag-controls').show();
        $('#titletag-results').show();

        // Initialize with current post type filter and no issue filter
        // Take snapshot for undo
        TitleTag.scanSnapshot = JSON.parse(JSON.stringify(TitleTag.allRows));
        TitleTag.appliedChanges = [];
        updateUndoState();

        TitleTag.postTypeFilter = $('#titletag-posttype-filter').val() || 'all';
        applyPostTypeFilter(TitleTag.postTypeFilter);

        // Show the scan-results Export CSV button if there are problematic rows
        var problemRows = TitleTag.allRows.filter(function (r) {
            return r.issue_type !== 'ok';
        });
        if (problemRows.length > 0) {
            $('#titletag-scan-export-btn').show();
        } else {
            $('#titletag-scan-export-btn').hide();
        }

        showToast('Scan complete. ' + TitleTag.allRows.length + ' posts/pages found.');
    }

    /* =========================================================
     * Stats
     * ========================================================= */
    function renderStats(stats) {
        $('#stat-total').text(stats.total || 0);
        $('#stat-with-titles').text(stats.with_titles || 0);
        $('#stat-without-titles').text(stats.without_titles || 0);
    }

    /* =========================================================
     * Post Type Filter (dimension filter)
     * ========================================================= */
    function applyPostTypeFilter(postType) {
        TitleTag.postTypeFilter = postType;

        // Filter allRows by post type
        if (postType === 'all') {
            TitleTag.typeFilteredRows = TitleTag.allRows.slice();
        } else {
            TitleTag.typeFilteredRows = TitleTag.allRows.filter(function (r) {
                return r.post_type === postType;
            });
        }

        // Recalculate stats from typeFilteredRows
        recalcStats();

        // Update filter counts
        updateFilterCounts();

        // Reset issue filter and re-apply
        resetFilter();
    }

    function recalcStats() {
        var rows = TitleTag.typeFilteredRows;
        var total = rows.length;
        var missing = 0;

        rows.forEach(function (r) {
            if (r.issue_type === 'missing') { missing++; }
        });

        $('#stat-total').text(total);
        $('#stat-without-titles').text(missing);
        $('#stat-with-titles').text(total - missing);
    }

    /* =========================================================
     * Filter Count Badges
     * ========================================================= */
    function updateFilterCounts() {
        var counts = { missing: 0, too_short: 0, too_long: 0, duplicate: 0 };

        TitleTag.typeFilteredRows.forEach(function (r) {
            if (counts.hasOwnProperty(r.issue_type)) {
                counts[r.issue_type]++;
            }
        });

        $('.titletag-filter-card').each(function () {
            var filter = $(this).data('filter');
            var count = counts[filter] || 0;
            var $countSpan = $(this).find('.titletag-filter-count');
            $countSpan.text('(' + count + ')');

            // Visually dim zero-count cards
            if (count === 0) {
                $(this).addClass('titletag-filter-card-empty');
            } else {
                $(this).removeClass('titletag-filter-card-empty');
            }
        });
    }

    /* =========================================================
     * Issue Filter
     * ========================================================= */
    function setFilter(filter) {
        // Toggle: clicking the already-active filter deselects it
        if (TitleTag.activeFilter === filter) {
            resetFilter(); return;
        }
        applyFilter(filter);
        // Mark card active
        $('.titletag-filter-card').removeClass('titletag-filter-active');
        $('.titletag-filter-card[data-filter="' + filter + '"]').addClass('titletag-filter-active');
    }

    function applyFilter(filter) {
        TitleTag.activeFilter = filter;
        TitleTag.appliedChanges = [];
        TitleTag.currentPage = 1;
        updateUndoState(); // sync both Undo button and Export CSV button

        if (filter === '') {
            TitleTag.visibleRows = TitleTag.typeFilteredRows.slice();
        } else {
            TitleTag.visibleRows = TitleTag.typeFilteredRows.filter(function (r) {
                return r.issue_type === filter;
            });
        }

        renderCurrentPage();
    }

    function resetFilter() {
        TitleTag.activeFilter = '';
        // Force-uncheck via native DOM to avoid browser caching issues
        $('input[name="titletag-filter"]').each(function () { this.checked = false; });
        $('.titletag-filter-card').removeClass('titletag-filter-active');
        applyFilter('');
    }

    /* =========================================================
     * Lock Rows
     * ========================================================= */
    function normalizeUrl(url) {
        return url.replace(/^https?:\/\//, '').replace(/\/+$/, '').toLowerCase();
    }

    function isRowLocked(postUrl) {
        if (!TitleTag.lockedUrls.length) { return false; }
        var norm = normalizeUrl(postUrl);
        return TitleTag.lockedUrls.some(function (u) {
            return normalizeUrl(u) === norm;
        });
    }

    function getSiteDomain() {
        try {
            return new URL(titleTagData.ajaxUrl).hostname.toLowerCase();
        } catch (e) { return ''; }
    }

    function openLockModal() {
        // Populate textarea with currently locked URLs
        $('#titletag-lock-urls-input').val(TitleTag.lockedUrls.join('\n'));
        $('#titletag-lock-modal').show();
    }

    function closeLockModal() {
        $('#titletag-lock-modal').hide();
    }

    function processLockUrls() {
        var raw = $('#titletag-lock-urls-input').val();
        var lines = raw.split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l.length > 0; });
        var hadLockedBefore = TitleTag.lockedUrls.length > 0;

        // Build a lookup map of all known post URLs (normalised)
        var knownMap = {};
        TitleTag.allRows.forEach(function (r) {
            knownMap[normalizeUrl(r.post_url)] = r.post_url; // normalised → original
        });

        var siteDomain = getSiteDomain();
        var validUrls = [];
        var notFound = [];
        var external = [];

        lines.forEach(function (url) {
            // Check if external domain
            try {
                var parsed = new URL(url);
                if (siteDomain && parsed.hostname.toLowerCase() !== siteDomain) {
                    external.push(url);
                    return;
                }
            } catch (e) {
                // Not a valid URL — treat as relative or malformed, try matching anyway
            }

            var norm = normalizeUrl(url);
            if (knownMap[norm]) {
                validUrls.push(knownMap[norm]); // Store the original URL
            } else {
                notFound.push(url);
            }
        });

        // Show alert for invalid URLs
        var msgs = [];
        if (external.length) {
            msgs.push('External URLs (not your domain):\n• ' + external.join('\n• '));
        }
        if (notFound.length) {
            msgs.push('URLs not found in scan results:\n• ' + notFound.join('\n• '));
        }
        if (msgs.length) {
            alert('Some URLs could not be locked:\n\n' + msgs.join('\n\n'));
        }

        // Update locked URLs and re-render
        TitleTag.lockedUrls = validUrls;
        closeLockModal();
        renderCurrentPage();

        if (validUrls.length > 0) {
            showToast(validUrls.length + ' row(s) locked.');
        } else if (hadLockedBefore && validUrls.length === 0) {
            showToast('All rows unlocked.');
        }
    }

    /* =========================================================
     * Pagination helpers
     * =========================================================*/
    function totalPages() {
        return Math.max(1, Math.ceil(TitleTag.visibleRows.length / PAGE_SIZE));
    }

    function pageRows() {
        var start = (TitleTag.currentPage - 1) * PAGE_SIZE;
        return TitleTag.visibleRows.slice(start, start + PAGE_SIZE);
    }

    function renderCurrentPage() {
        renderTable(pageRows(), (TitleTag.currentPage - 1) * PAGE_SIZE);
        renderPagination();
    }

    /* =========================================================
     * Table Rendering
     * ========================================================= */
    function renderTable(rows, startIdx) {
        var $tbody = $('#titletag-tbody');
        $tbody.empty();

        if (TitleTag.visibleRows.length === 0) {
            $tbody.append(
                '<tr><td colspan="6" style="text-align:center;padding:30px;color:#646970;">' +
                (TitleTag.activeFilter ? 'No issues match the selected filter.' : 'No posts found.') +
                '</td></tr>'
            );
            return;
        }

        var tmpl = document.getElementById('titletag-row-template');

        rows.forEach(function (row, i) {
            var globalIdx = startIdx + i;
            var $tr = $(document.importNode(tmpl.content, true).firstElementChild);

            $tr.attr('data-post-id', row.post_id);
            $tr.attr('data-issue', row.issue_type);
            $tr.attr('data-post-url', row.post_url);
            $tr.attr('data-old-title', row.rendered_title);

            $tr.find('.titletag-col-num').text(globalIdx + 1);
            $tr.find('.titletag-post-title').text(row.post_title);
            $tr.find('.titletag-post-type-badge').text(row.post_type);
            $tr.find('.titletag-edit-link').attr('href', row.edit_url);
            $tr.find('.titletag-post-url').attr('href', row.post_url).text(shortenUrl(row.post_url));
            $tr.find('.titletag-current-title-text').text(row.rendered_title || '(empty)');
            $tr.find('.titletag-issue-badge-wrap').html(buildIssueBadge(row.issue_type));
            var currentTitleLen = (row.rendered_title || '').length;
            $tr.find('.titletag-current-char-count').text(currentTitleLen + ' chars');
            $tr.find('.titletag-char-count').text('0');

            // Lock styling
            if (isRowLocked(row.post_url)) {
                $tr.addClass('titletag-row-locked');
                $tr.find('.titletag-generate-btn').prop('disabled', true);
                $tr.find('.titletag-action-status').html(
                    '<span class="titletag-lock-badge">' +
                    '<span class="dashicons dashicons-lock"></span> Locked' +
                    '</span>'
                );
            }

            $tbody.append($tr);
        });
    }

    function buildIssueBadge(issue_type) {
        var labels = {
            missing: 'Missing',
            too_short: 'Too Short',
            too_long: 'Too Long',
            duplicate: 'Duplicate',
            ok: 'OK'
        };
        return '<span class="titletag-issue-badge titletag-badge-' + issue_type + '">' +
            (labels[issue_type] || issue_type) + '</span>';
    }

    function shortenUrl(url) {
        try {
            var u = new URL(url);
            var p = u.pathname;
            return p.length > 40 ? p.substring(0, 37) + '\u2026' : p;
        } catch (e) { return url; }
    }

    /* =========================================================
     * Pagination Rendering
     * ========================================================= */
    function renderPagination() {
        var $pag = $('#titletag-pagination');
        var $info = $('#titletag-pagination-info');
        var $ctrl = $('#titletag-pagination-controls');
        var total = TitleTag.visibleRows.length;
        var tp = totalPages();
        var cp = TitleTag.currentPage;

        if (total === 0) { $pag.hide(); return; }

        var start = (cp - 1) * PAGE_SIZE + 1;
        var end = Math.min(cp * PAGE_SIZE, total);
        $info.text('Showing ' + start + '\u2013' + end + ' of ' + total);

        $ctrl.empty();

        // Prev
        var $prev = $('<button class="button">&laquo; Prev</button>');
        if (cp <= 1) { $prev.prop('disabled', true); }
        else { $prev.on('click', function () { goToPage(cp - 1); }); }
        $ctrl.append($prev);

        // Page numbers
        var pages = buildPageNumbers(cp, tp);
        pages.forEach(function (p) {
            if (p === '\u2026') {
                $ctrl.append('<span class="titletag-pagination-ellipsis">\u2026</span>');
            } else {
                var $btn = $('<button class="button">' + p + '</button>');
                if (p === cp) { $btn.addClass('current-page'); }
                else {
                    (function (pg) {
                        $btn.on('click', function () { goToPage(pg); });
                    })(p);
                }
                $ctrl.append($btn);
            }
        });

        // Next
        var $next = $('<button class="button">Next &raquo;</button>');
        if (cp >= tp) { $next.prop('disabled', true); }
        else { $next.on('click', function () { goToPage(cp + 1); }); }
        $ctrl.append($next);

        if (tp > 1) { $pag.show(); }
        else { $pag.hide(); }
    }

    function buildPageNumbers(current, total) {
        if (total <= 7) {
            var arr = [];
            for (var i = 1; i <= total; i++) { arr.push(i); }
            return arr;
        }
        var pages = [1];
        if (current > 3) { pages.push('\u2026'); }
        for (var p = Math.max(2, current - 1); p <= Math.min(total - 1, current + 1); p++) {
            pages.push(p);
        }
        if (current < total - 2) { pages.push('\u2026'); }
        pages.push(total);
        return pages;
    }

    function goToPage(page) {
        TitleTag.currentPage = page;
        renderCurrentPage();
        // Scroll to table top
        $('html, body').animate({ scrollTop: $('#titletag-results').offset().top - 40 }, 200);
    }

    /* =========================================================
     * Single Generate
     * ========================================================= */
    function generateSingle($row, isBulk) {
        var postId = $row.data('post-id');
        var $editable = $row.find('.titletag-suggested-editable');
        var $indicator = $row.find('.titletag-generating-indicator');
        var $genBtn = $row.find('.titletag-generate-btn');
        var $applyBtn = $row.find('.titletag-apply-btn');

        $editable.hide();
        $indicator.show();
        $genBtn.prop('disabled', true);
        $applyBtn.prop('disabled', true);

        return $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_generate',
                nonce: titleTagData.nonce,
                post_id: postId,
                force: 'false'
            }
        }).then(function (res) {
            $indicator.hide();
            $editable.show();
            $genBtn.prop('disabled', false);

            if (res.success) {
                $editable.text(res.data.title).addClass('has-suggestion');
                updateCharCounter($editable);
                $applyBtn.prop('disabled', false);
                // Show primary keyword if returned
                var $kwEl = $row.find('.titletag-primary-keyword');
                if (res.data.keyword) {
                    $kwEl.text('Primary Keyword: ' + res.data.keyword).show();
                } else {
                    $kwEl.text('').hide();
                }
                setRowStatus($row, '', '');
            } else {
                setRowStatus($row, 'Error: ' + res.data.message, 'error');
            }
        }).fail(function () {
            $indicator.hide();
            $editable.show();
            $genBtn.prop('disabled', false);
            setRowStatus($row, 'Request failed.', 'error');
        });
    }

    /* =========================================================
     * Apply Single
     * ========================================================= */
    function applySingle($row) {
        var postId = parseInt($row.data('post-id'), 10);
        var postUrl = $row.attr('data-post-url') || '';
        var oldTitle = $row.attr('data-old-title') || '';
        var newTitle = $row.find('.titletag-suggested-editable').text().trim();

        if (!newTitle) { showToast('Title cannot be empty.', 'error'); return; }

        var $applyBtn = $row.find('.titletag-apply-btn');
        $applyBtn.prop('disabled', true).text('Applying\u2026');
        setRowStatus($row, '', '');

        $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_apply',
                nonce: titleTagData.nonce,
                post_id: postId,
                new_title: newTitle
            },
            success: function (res) {
                if (res.success) {
                    // --- Step 1: Green flash animation ---
                    $row.addClass('titletag-row-green');
                    $applyBtn.addClass('titletag-apply-btn-applied').text('Applied').prop('disabled', true);
                    $row.attr('data-old-title', newTitle);

                    // Compute new issue type immediately
                    var newIssue = getIssueType(newTitle);

                    // Update the in-memory data arrays right away
                    updateRowIssueInData(postId, newTitle, newIssue);

                    // Update the visible badge & title text inside the row during the flash
                    $row.find('.titletag-current-title-text').text(newTitle);
                    $row.find('.titletag-issue-badge-wrap').html(buildIssueBadge(newIssue));
                    $row.find('.titletag-current-char-count').text(newTitle.length + ' chars');

                    // Update filter count badges immediately so numbers are live
                    updateFilterCounts();
                    recalcStats();

                    TitleTag.appliedChanges.push({ post_id: postId, post_url: postUrl, old_title: oldTitle, new_title: newTitle });
                    updateUndoState();

                    // --- Step 2: After animation ends, migrate row to correct filter ---
                    setTimeout(function () {
                        // Clear the suggestion area
                        $row.find('.titletag-suggested-editable').text('').removeClass('has-suggestion');
                        $row.find('.titletag-char-count').text('0').removeClass('chars-ok chars-short chars-long');
                        $row.find('.titletag-primary-keyword').text('').hide();
                        $applyBtn.removeClass('titletag-apply-btn-applied').text('Apply').prop('disabled', true);
                        $row.removeClass('titletag-row-green');

                        // Migrate the row out of the current filter if it no longer belongs
                        migrateRowAfterApply($row, postId, newIssue);
                    }, 3500);

                } else {
                    setRowStatus($row, res.data.message, 'error');
                    $applyBtn.text('Apply').prop('disabled', false);
                }
            },
            error: function () {
                setRowStatus($row, 'Request failed.', 'error');
                $applyBtn.text('Apply').prop('disabled', false);
            }
        });
    }

    /* =========================================================
     * Issue Type Helpers
     * ========================================================= */

    /** Compute the issue type string from a title value */
    function getIssueType(title) {
        var len = (title || '').length;
        if (len === 0) { return 'missing'; }
        if (len < 30) { return 'too_short'; }
        if (len > 60) { return 'too_long'; }
        return 'ok';
    }

    /**
     * Update rendered_title and issue_type in all three data arrays
     * for a given post_id after a successful apply.
     */
    function updateRowIssueInData(postId, newTitle, newIssue) {
        function patchRow(r) {
            if (r.post_id === postId) {
                r.rendered_title = newTitle;
                r.issue_type = newIssue;
            }
        }
        TitleTag.allRows.forEach(patchRow);
        TitleTag.typeFilteredRows.forEach(patchRow);
        TitleTag.visibleRows.forEach(patchRow);
    }

    /**
     * After the green flash animation, check whether the row still belongs
     * in the current active filter. If not, animate it out and re-render.
     */
    function migrateRowAfterApply($row, postId, newIssue) {
        var activeFilter = TitleTag.activeFilter;

        // If no filter is active, or the new issue still matches the filter,
        // just leave the row in place (it now has the correct badge already).
        if (!activeFilter || activeFilter === newIssue) {
            return;
        }

        // The row no longer belongs in the current filter view.
        // Animate it out with a slide-up + fade.
        $row.addClass('titletag-row-migrating-out');

        setTimeout(function () {
            // Remove from visibleRows (the current filter's displayed list)
            TitleTag.visibleRows = TitleTag.visibleRows.filter(function (r) {
                return r.post_id !== postId;
            });

            // Fix page if now over-filled
            if (TitleTag.currentPage > totalPages()) {
                TitleTag.currentPage = Math.max(1, totalPages());
            }

            // Re-render the table and pagination
            renderCurrentPage();
        }, 450); // matches CSS transition duration
    }


    /* =========================================================
     * Skip (frontend-only — removes row from session with animation)
     * ========================================================= */
    function skipRow($row) {
        var postId = parseInt($row.data('post-id'), 10);
        TitleTag.skippedIds.push(postId);

        // Determine the skipped row's issue type for stat adjustment

        // Disable buttons immediately
        $row.find('.titletag-apply-btn, .titletag-generate-btn, .titletag-skip-btn').prop('disabled', true);

        // Step 1: Turn row grey
        $row.addClass('titletag-row-being-skipped');

        // Step 2: After grey shows, fade out
        setTimeout(function () {
            $row.addClass('titletag-row-fade-out');

            // Step 3: After fade-out completes, remove from data and re-render
            setTimeout(function () {
                // Remove from data arrays
                TitleTag.allRows = TitleTag.allRows.filter(function (r) {
                    return r.post_id !== postId;
                });
                TitleTag.typeFilteredRows = TitleTag.typeFilteredRows.filter(function (r) {
                    return r.post_id !== postId;
                });
                TitleTag.visibleRows = TitleTag.visibleRows.filter(function (r) {
                    return r.post_id !== postId;
                });

                // Recalculate stats from current type-filtered rows
                recalcStats();

                // Update filter count badges after skip
                updateFilterCounts();

                // Fix current page if it now exceeds total pages
                if (TitleTag.currentPage > totalPages()) {
                    TitleTag.currentPage = Math.max(1, totalPages());
                }

                // Re-render table and pagination
                renderCurrentPage();
            }, 400);
        }, 300);
    }

    /* =========================================================
     * Bulk Generate
     * ========================================================= */
    function bulkGenerate() {
        if (!titleTagData.hasApiKey) {
            showToast('OpenAI API key not configured.', 'error'); return;
        }

        var $rows = $('#titletag-tbody .titletag-row:not(.titletag-row-skipped):not(.titletag-row-locked)');
        var total = $rows.length;
        if (total === 0) { showToast('No rows visible to generate.', 'error'); return; }

        TitleTag.cancelGeneration = false;
        $('#titletag-bulk-progress').show();
        $('#titletag-bulk-generate-btn').prop('disabled', true);
        updateBulkProgress(0, total);

        var rowArray = $rows.toArray();
        var idx = 0;

        function next() {
            if (TitleTag.cancelGeneration) { finishBulkGenerate(true); return; }
            if (idx >= rowArray.length) { finishBulkGenerate(false); return; }
            var $row = $(rowArray[idx++]);
            generateSingle($row, true).always(function () {
                updateBulkProgress(idx, total);
                next();
            });
        }

        next();
    }

    function updateBulkProgress(done, total) {
        var pct = total > 0 ? Math.round((done / total) * 100) : 0;
        $('#titletag-bulk-progress-text').text('Generating: ' + done + ' of ' + total);
        $('#titletag-bulk-progress-fill').css('width', pct + '%');
    }

    function finishBulkGenerate(cancelled) {
        $('#titletag-bulk-progress').hide();
        $('#titletag-bulk-generate-btn').prop('disabled', false);
        if (cancelled) {
            // Clear all generated suggestions, char counters, and keywords
            $('.titletag-suggested-editable').text('').removeClass('has-suggestion');
            $('.titletag-char-count').text('0').removeClass('chars-ok chars-short chars-long');
            $('.titletag-primary-keyword').text('').hide();
            $('.titletag-apply-btn').prop('disabled', true);
            showToast('Generation cancelled.', 'error');
        } else {
            showToast('Bulk generation complete!');
        }
    }

    /* =========================================================
     * Bulk Apply
     * ========================================================= */
    function bulkApply() {
        var changes = [];
        $('#titletag-tbody .titletag-row:not(.titletag-row-skipped):not(.titletag-row-locked)').each(function () {
            var $row = $(this);
            var postId = parseInt($row.data('post-id'), 10);
            var postUrl = $row.attr('data-post-url') || '';
            var oldTitle = $row.attr('data-old-title') || '';
            var newTitle = $row.find('.titletag-suggested-editable').text().trim();
            if (postId && newTitle) {
                changes.push({ post_id: postId, new_title: newTitle, post_url: postUrl, old_title: oldTitle });
            }
        });

        if (changes.length === 0) {
            showToast('No suggestions to apply. Use Generate first.', 'error'); return;
        }

        if (!confirm('Apply all ' + changes.length + ' suggested titles now?')) { return; }

        $('#titletag-bulk-apply-btn').prop('disabled', true).text('Applying\u2026');

        $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_bulk_apply',
                nonce: titleTagData.nonce,
                changes: JSON.stringify(changes.map(function (c) { return { post_id: c.post_id, new_title: c.new_title }; }))
            },
            success: function (res) {
                $('#titletag-bulk-apply-btn')
                    .prop('disabled', false)
                    .html('<span class="dashicons dashicons-yes"></span> Bulk Apply Titles Below');

                if (res.success) {
                    var s = res.data;
                    showToast('Applied: ' + s.applied + (s.failed ? ', Failed: ' + s.failed : ''));

                    changes.forEach(function (c) {
                        var $row = $('#titletag-tbody .titletag-row[data-post-id="' + c.post_id + '"]');
                        if (!$row.length) { return; }

                        var newIssue = getIssueType(c.new_title);

                        // Update in-memory data arrays
                        updateRowIssueInData(c.post_id, c.new_title, newIssue);

                        // Green row flash + immediate badge/title update
                        $row.addClass('titletag-row-green');
                        $row.find('.titletag-current-title-text').text(c.new_title);
                        $row.find('.titletag-issue-badge-wrap').html(buildIssueBadge(newIssue));
                        $row.find('.titletag-current-char-count').text(c.new_title.length + ' chars');
                        $row.find('.titletag-suggested-editable').text('').removeClass('has-suggestion');
                        $row.find('.titletag-char-count').text('0').removeClass('chars-ok chars-short chars-long');
                        $row.find('.titletag-apply-btn').prop('disabled', true).text('Apply');

                        TitleTag.appliedChanges.push({ post_id: c.post_id, post_url: c.post_url, old_title: c.old_title, new_title: c.new_title });

                        // Migrate row out after animation
                        (function ($r, pid, issue) {
                            setTimeout(function () {
                                $r.removeClass('titletag-row-green');
                                migrateRowAfterApply($r, pid, issue);
                            }, 3500);
                        })($row, c.post_id, newIssue);
                    });

                    // Refresh counts immediately after all updates
                    updateFilterCounts();
                    recalcStats();

                    updateUndoState();
                } else {
                    showToast('Bulk apply error: ' + res.data.message, 'error');
                }
            },
            error: function () {
                $('#titletag-bulk-apply-btn')
                    .prop('disabled', false)
                    .html('<span class="dashicons dashicons-yes"></span> Bulk Apply Titles Below');
                showToast('Request failed.', 'error');
            }
        });
    }

    /* =========================================================
     * Export CSV
     * ========================================================= */
    function exportCSV() {
        if (TitleTag.appliedChanges.length === 0) {
            showToast('No applied changes to export.', 'error'); return;
        }

        $('#titletag-export-csv-btn').prop('disabled', true).text('Exporting\u2026');

        $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_export_csv',
                nonce: titleTagData.nonce,
                changes: JSON.stringify(TitleTag.appliedChanges)
            },
            success: function (res) {
                $('#titletag-export-csv-btn')
                    .prop('disabled', false)
                    .html('<span class="dashicons dashicons-download"></span> Export Changes in CSV');
                if (res.success) {
                    // Extract filename from the URL and set it explicitly so the
                    // browser saves as .csv regardless of server content-type.
                    var dlUrl = res.data.download_url;
                    var dlName = dlUrl.split('/').pop().split('?')[0] || 'titletag-changes.csv';
                    if (dlName.slice(-4).toLowerCase() !== '.csv') { dlName += '.csv'; }
                    var $a = $('<a>')
                        .attr('href', dlUrl)
                        .attr('download', dlName)
                        .css('display', 'none');
                    $('body').append($a);
                    $a[0].click();
                    $a.remove();
                    showToast('CSV ready \u2014 downloading.');
                } else {
                    showToast('Export error: ' + res.data.message, 'error');
                }
            },
            error: function () {
                $('#titletag-export-csv-btn')
                    .prop('disabled', false)
                    .html('<span class="dashicons dashicons-download"></span> Export Changes in CSV');
                showToast('Export failed.', 'error');
            }
        });
    }

    /* =========================================================
     * Export Scan Results CSV (client-side Blob)
     * Exports all posts/pages with issues from the current scan.
     * ========================================================= */
    function exportScanCSV() {
        // Include all issue types except 'ok'
        var issueRows = TitleTag.allRows.filter(function (r) {
            return r.issue_type !== 'ok';
        });

        if (issueRows.length === 0) {
            showToast('No issues found to export.', 'error'); return;
        }

        var issueLabels = {
            missing: 'Missing Title',
            too_short: 'Title Too Short (< 30 chars)',
            too_long: 'Title Too Long (> 60 chars)',
            duplicate: 'Duplicate Title'
        };

        // Build CSV string
        var lines = [];
        lines.push(csvRow(['Page Name', 'Page URL', 'Issue', 'Current Title']));
        issueRows.forEach(function (r) {
            lines.push(csvRow([
                r.post_title || '',
                r.post_url || '',
                issueLabels[r.issue_type] || r.issue_type,
                r.rendered_title || ''
            ]));
        });

        var csvContent = lines.join('\r\n');
        var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var filename = 'titletag-issues-' + new Date().toISOString().slice(0, 10) + '.csv';

        var $a = $('<a>')
            .attr('href', url)
            .attr('download', filename)
            .css('display', 'none');
        $('body').append($a);
        $a[0].click();
        $a.remove();
        URL.revokeObjectURL(url);

        showToast('CSV downloaded \u2014 ' + issueRows.length + ' issue(s) exported.');
    }

    /* Helper: escape a single CSV field */
    function csvRow(fields) {
        return fields.map(function (f) {
            var s = String(f).replace(/"/g, '""');
            return '"' + s + '"';
        }).join(',');
    }

    /* =========================================================
     * Undo
     * ========================================================= */
    function updateUndoState() {
        var hasChanges = TitleTag.appliedChanges.length > 0;
        $('#titletag-undo-btn').prop('disabled', !hasChanges);
        if (hasChanges) {
            $('#titletag-export-csv-btn').show();
        } else {
            $('#titletag-export-csv-btn').hide();
        }
    }

    function undoChanges() {
        if (TitleTag.appliedChanges.length === 0) { return; }
        if (!confirm('Undo all ' + TitleTag.appliedChanges.length + ' applied change(s)? This will revert titles in the database to their original values.')) { return; }

        var $btn = $('#titletag-undo-btn');
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-undo"></span> Undoing\u2026');

        // Deduplicate: if same post_id was changed multiple times, only revert to the FIRST old_title
        var revertMap = {};
        TitleTag.appliedChanges.forEach(function (c) {
            if (!revertMap[c.post_id]) {
                revertMap[c.post_id] = c.old_title; // earliest old_title = original
            }
        });
        var revertPayload = Object.keys(revertMap).map(function (pid) {
            return { post_id: parseInt(pid, 10), new_title: revertMap[pid] };
        });

        $.ajax({
            url: titleTagData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'titletag_bulk_apply',
                nonce: titleTagData.nonce,
                changes: JSON.stringify(revertPayload)
            },
            success: function (res) {
                $btn.html('<span class="dashicons dashicons-undo"></span> Undo');

                if (res.success) {
                    // Restore from snapshot
                    TitleTag.allRows = JSON.parse(JSON.stringify(TitleTag.scanSnapshot));
                    TitleTag.appliedChanges = [];
                    updateUndoState();

                    // Re-apply filters and re-render
                    applyPostTypeFilter(TitleTag.postTypeFilter);
                    showToast('All changes undone. Titles reverted to scan results.');
                } else {
                    showToast('Undo failed: ' + res.data.message, 'error');
                    $btn.prop('disabled', false);
                }
            },
            error: function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-undo"></span> Undo');
                showToast('Undo request failed.', 'error');
            }
        });
    }

    /* =========================================================
     * Helpers
     * ========================================================= */
    function updateCharCounter($editable) {
        var len = $editable.text().trim().length;
        var $counter = $editable.closest('td').find('.titletag-char-count');
        $counter.text(len).removeClass('chars-ok chars-short chars-long');
        if (len === 0) { /* no colour */ }
        else if (len < 30) { $counter.addClass('chars-short'); }
        else if (len > 60) { $counter.addClass('chars-long'); }
        else { $counter.addClass('chars-ok'); }
    }

    function setRowStatus($row, msg, type) {
        var $s = $row.find('.titletag-action-status');
        $s.removeClass('success error').text(msg);
        if (type) { $s.addClass(type); }
    }

    function setProgress(pct) {
        $('#titletag-progress-fill').css('width', pct + '%');
        $('#titletag-progress-pct').text(pct + '%');
    }

    function showToast(msg, type) {
        var $t = $('<div class="titletag-toast"><span class="titletag-toast-message"></span></div>');
        $t.find('.titletag-toast-message').text(msg);
        if (type === 'error') { $t.addClass('toast-error'); }
        $('body').append($t);
        setTimeout(function () { $t.addClass('show'); }, 50);
        setTimeout(function () {
            $t.removeClass('show');
            setTimeout(function () { $t.remove(); }, 400);
        }, 3500);
    }

})(jQuery);
